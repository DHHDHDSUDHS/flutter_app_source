# OmniTools AI – All-in-One Utility & AI Assistant (Flutter)

Eight tools in one Flutter app (Android + iOS), AdMob monetization built in, and a single file (`lib/core/constants.dart`) to re-skin everything.

## Features
- **AI Hub** – chat, summarize, write, brainstorm. OpenAI or Gemini (user supplies the key). Free daily credits + rewarded-ad top-ups.
- **PDF Reader** – open and read local PDFs.
- **Image Compressor** – quality slider, before/after size, share/save.
- **QR & Barcode** – live scanner (torch, camera switch) and QR generator.
- **Password Generator** – secure random, strength meter, copy.
- **Unit Converter** – length, mass, volume, speed, data, temperature.
- **Age & Date** – exact age, date difference, next-birthday countdown.
- Light / Dark / System theme (Material 3), Provider state management.
- AdMob: banner, interstitial (frequency capped), rewarded. Test ads on by default.

## Requirements
Flutter 3.22+ (Dart 3.3+), Android Studio or VS Code, a device or emulator. Camera features need a real device.

## Quick start
```bash
./setup.sh com.yourcompany      # creates android/ios, patches config, pub get, analyze, test
flutter run
```
Manual steps: `flutter create --org com.yourcompany --project-name omnitools_ai .`, then `python3 tools/patch_platform_config.py`, then `flutter pub get`.

## Re-skin in minutes
Edit `lib/core/constants.dart`: app name, colors, support email, AI default models, credit rules, AdMob unit IDs. Details in `documentation/index.html`.

## Tests
`flutter test` runs unit tests (password, units, age, formatting, AI service with a mocked HTTP client) and a widget smoke test.
`python3 tools/verify_project.py` runs static checks without the Flutter SDK.

## Project structure
```
lib/core        constants (re-skin), theme, pure-Dart utils
lib/models      ChatMessage, AiMode
lib/services    AiService (HTTP), AdService (AdMob)
lib/providers   SettingsProvider, AiChatProvider
lib/screens     one file per tool
lib/widgets     ToolCard, BannerAdWidget
test/           unit + widget tests
tools/          setup helpers
```

## Support & license
Support: see `AppConstants.supportEmail`. Licensed per the marketplace license you purchased. Third-party packages keep their own licenses (listed in pubspec.yaml).
