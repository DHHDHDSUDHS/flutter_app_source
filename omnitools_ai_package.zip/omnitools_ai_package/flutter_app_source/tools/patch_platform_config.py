#!/usr/bin/env python3
"""Adds the native config this app needs after `flutter create .` (idempotent).
   Android: INTERNET + CAMERA permissions, AdMob APPLICATION_ID.
   iOS:     camera/photo usage strings, GADApplicationIdentifier.
   Usage:   python3 tools/patch_platform_config.py [ANDROID_APP_ID] [IOS_APP_ID]
   Defaults are Google's TEST app IDs. Replace before publishing."""
import sys, pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
ANDROID_ID = sys.argv[1] if len(sys.argv) > 1 else "ca-app-pub-3940256099942544~3347511713"
IOS_ID = sys.argv[2] if len(sys.argv) > 2 else "ca-app-pub-3940256099942544~1458002511"

def patch_manifest(path: pathlib.Path):
    s = path.read_text()
    changed = False
    for perm in ("android.permission.INTERNET", "android.permission.CAMERA"):
        if perm not in s:
            s = s.replace("<application", f'<uses-permission android:name="{perm}"/>\n    <application', 1)
            changed = True
    if "com.google.android.gms.ads.APPLICATION_ID" not in s:
        meta = ('<meta-data android:name="com.google.android.gms.ads.APPLICATION_ID"\n'
                f'            android:value="{ANDROID_ID}"/>\n    </application>')
        s = s.replace("</application>", meta, 1)
        changed = True
    if changed: path.write_text(s)
    return changed

def patch_plist(path: pathlib.Path):
    s = path.read_text()
    entries = {
        "GADApplicationIdentifier": IOS_ID,
        "NSCameraUsageDescription": "Camera is used to scan QR codes and barcodes.",
        "NSPhotoLibraryUsageDescription": "Photos are used to compress images.",
    }
    add = "".join(f"\t<key>{k}</key>\n\t<string>{v}</string>\n" for k, v in entries.items() if k not in s)
    if add:
        s = s.replace("</dict>\n</plist>", add + "</dict>\n</plist>", 1)
        path.write_text(s)
    return bool(add)

manifest = ROOT / "android/app/src/main/AndroidManifest.xml"
plist = ROOT / "ios/Runner/Info.plist"
if manifest.exists(): print("AndroidManifest patched" if patch_manifest(manifest) else "AndroidManifest already OK")
else: print("android/ not found - run `flutter create .` first")
if plist.exists(): print("Info.plist patched" if patch_plist(plist) else "Info.plist already OK")
else: print("ios/ not found - skipped")
