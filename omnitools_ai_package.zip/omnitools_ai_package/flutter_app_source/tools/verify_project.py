#!/usr/bin/env python3
"""Static sanity checks that need no Flutter SDK.
   Checks: balanced brackets, import resolution, pubspec coverage, leftovers.
   Usage: python3 tools/verify_project.py   (run from the project root)
"""
import re, sys, pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
PKG = "omnitools_ai"
errors, warnings = [], []

def strip_code(src: str) -> str:
    """Remove comments and string contents so brackets can be counted."""
    out, i, n = [], 0, len(src)
    while i < n:
        c, nxt = src[i], src[i:i + 2]
        if nxt == "//":
            while i < n and src[i] != "\n": i += 1
        elif nxt == "/*":
            j = src.find("*/", i + 2); i = n if j < 0 else j + 2
        elif c in "'\"":
            raw = i > 0 and src[i - 1] == "r"
            trip = src[i:i + 3] in ("'''", '"""')
            q = src[i:i + 3] if trip else c
            i += len(q)
            while i < n and not src.startswith(q, i):
                if src[i] == "\\" and not raw: i += 1
                i += 1
            i += len(q)
            out.append('""')
        else:
            out.append(c); i += 1
    return "".join(out)

def check_balance(path, code):
    pairs, stack = {")": "(", "]": "[", "}": "{"}, []
    line = 1
    for ch in code:
        if ch == "\n": line += 1
        if ch in "([{": stack.append((ch, line))
        elif ch in ")]}":
            if not stack or stack[-1][0] != pairs[ch]:
                errors.append(f"{path}: unbalanced '{ch}' near line {line}"); return
            stack.pop()
    if stack: errors.append(f"{path}: unclosed '{stack[-1][0]}' from line {stack[-1][1]}")

pubspec = (ROOT / "pubspec.yaml").read_text()
declared = set(re.findall(r"^  ([a-z_0-9]+):", pubspec, re.M))
used = set()
files = sorted(list((ROOT / "lib").rglob("*.dart")) + list((ROOT / "test").rglob("*.dart")))

for f in files:
    rel = f.relative_to(ROOT)
    src = f.read_text()
    check_balance(rel, strip_code(src))
    for m in re.finditer(r"""^import\s+['"]([^'"]+)['"]""", src, re.M):
        target = m.group(1)
        if target.startswith("dart:"): continue
        if target.startswith("package:"):
            pkg, _, sub = target[8:].partition("/")
            used.add(pkg)
            if pkg == PKG and not (ROOT / "lib" / sub).exists():
                errors.append(f"{rel}: missing file for {target}")
        elif not (f.parent / target).resolve().exists():
            errors.append(f"{rel}: unresolved import {target}")
    if re.search(r"(?<!debug)print\(", src):
        warnings.append(f"{rel}: contains print()")
    if "TODO" in src: warnings.append(f"{rel}: TODO left")

for p in sorted(used - {PKG, "flutter", "flutter_test"}):
    if p not in declared: errors.append(f"package '{p}' is imported but not in pubspec.yaml")
for p in sorted(declared - used - {"flutter", "flutter_test", "flutter_lints", "sdk"}):
    warnings.append(f"package '{p}' is in pubspec.yaml but never imported")

# every screen is reachable from the home grid
home = (ROOT / "lib/screens/home_screen.dart").read_text()
for s in (ROOT / "lib/screens").glob("*_screen.dart"):
    if s.name != "home_screen.dart" and s.name not in home:
        errors.append(f"{s.name} is not linked from home_screen.dart")

print(f"Checked {len(files)} Dart files")
for w in warnings: print("WARN ", w)
for e in errors: print("ERROR", e)
print("RESULT:", "FAIL" if errors else "OK")
sys.exit(1 if errors else 0)
