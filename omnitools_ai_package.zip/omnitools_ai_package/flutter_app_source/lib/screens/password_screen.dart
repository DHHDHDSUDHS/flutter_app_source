import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/utils/password_generator.dart';

class PasswordScreen extends StatefulWidget {
  const PasswordScreen({super.key});

  @override
  State<PasswordScreen> createState() => _PasswordScreenState();
}

class _PasswordScreenState extends State<PasswordScreen> {
  PasswordOptions _options = const PasswordOptions();
  String _password = '';

  @override
  void initState() {
    super.initState();
    _generate();
  }

  void _generate() {
    if (!_options.hasAny) return;
    setState(() => _password = PasswordGenerator.generate(_options));
  }

  void _update(PasswordOptions o) {
    // Keep at least one character set enabled.
    if (!o.hasAny) return;
    _options = o;
    _generate();
  }

  @override
  Widget build(BuildContext context) {
    final bits = PasswordGenerator.entropyBits(_options);
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Password Generator')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: scheme.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              children: [
                SelectableText(
                  _password,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontFamily: 'monospace', fontSize: 20, letterSpacing: 1),
                ),
                const SizedBox(height: 12),
                Text('${PasswordGenerator.strengthLabel(bits)} · ${bits.round()} bits',
                    style: TextStyle(color: scheme.primary, fontWeight: FontWeight.w600)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: _generate,
                  icon: const Icon(Icons.refresh),
                  label: const Text('Generate'),
                ),
              ),
              const SizedBox(width: 8),
              OutlinedButton.icon(
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: _password));
                  ScaffoldMessenger.of(context)
                      .showSnackBar(const SnackBar(content: Text('Copied')));
                },
                icon: const Icon(Icons.copy),
                label: const Text('Copy'),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Text('Length: ${_options.length}'),
          Slider(
            value: _options.length.toDouble(),
            min: 8,
            max: 64,
            divisions: 56,
            onChanged: (v) => _update(_options.copyWith(length: v.round())),
          ),
          SwitchListTile(
              title: const Text('Uppercase (A-Z)'),
              value: _options.upper,
              onChanged: (v) => _update(_options.copyWith(upper: v))),
          SwitchListTile(
              title: const Text('Lowercase (a-z)'),
              value: _options.lower,
              onChanged: (v) => _update(_options.copyWith(lower: v))),
          SwitchListTile(
              title: const Text('Numbers (0-9)'),
              value: _options.digits,
              onChanged: (v) => _update(_options.copyWith(digits: v))),
          SwitchListTile(
              title: const Text('Symbols (!@#…)'),
              value: _options.symbols,
              onChanged: (v) => _update(_options.copyWith(symbols: v))),
        ],
      ),
    );
  }
}
