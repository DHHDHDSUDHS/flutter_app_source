import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../core/constants.dart';
import '../models/ai_mode.dart';
import '../models/chat_message.dart';
import '../providers/ai_chat_provider.dart';
import '../providers/settings_provider.dart';
import '../services/ad_service.dart';
import 'settings_screen.dart';

class AiHubScreen extends StatelessWidget {
  const AiHubScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => AiChatProvider(),
      child: const _AiHubBody(),
    );
  }
}

class _AiHubBody extends StatefulWidget {
  const _AiHubBody();

  @override
  State<_AiHubBody> createState() => _AiHubBodyState();
}

class _AiHubBodyState extends State<_AiHubBody> {
  final _input = TextEditingController();
  final _scroll = ScrollController();

  @override
  void dispose() {
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _scrollDown() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      }
    });
  }

  Future<void> _send() async {
    final settings = context.read<SettingsProvider>();
    final chat = context.read<AiChatProvider>();
    if (_input.text.trim().isEmpty) return;
    if (!settings.hasCredits) {
      _showOutOfCredits(settings);
      return;
    }
    final text = _input.text;
    _input.clear();
    final future = chat.send(text, settings);
    _scrollDown();
    await future;
    _scrollDown();
  }

  void _showOutOfCredits(SettingsProvider settings) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Out of free credits'),
        content: Text(
            'Watch a short ad to get ${AppConstants.creditsPerRewardedAd} more AI messages.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Not now')),
          FilledButton(
            onPressed: () {
              Navigator.pop(ctx);
              AdService.instance.showRewarded(
                onReward: () => settings.grantCredits(AppConstants.creditsPerRewardedAd),
                onUnavailable: () => ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('No ad available right now. Try again soon.')),
                ),
              );
            },
            child: const Text('Watch ad'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final chat = context.watch<AiChatProvider>();
    final settings = context.watch<SettingsProvider>();
    final scheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Hub'),
        actions: [
          if (AppConstants.adsEnabled)
            Center(
              child: Padding(
                padding: const EdgeInsets.only(right: 4),
                child: Chip(
                  avatar: const Icon(Icons.bolt, size: 16),
                  label: Text('${settings.aiCredits}'),
                  visualDensity: VisualDensity.compact,
                ),
              ),
            ),
          IconButton(
            tooltip: 'Clear',
            icon: const Icon(Icons.delete_outline),
            onPressed: chat.messages.isEmpty ? null : chat.clear,
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            SizedBox(
              height: 48,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                children: [
                  for (final m in AiMode.values)
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        avatar: Icon(m.icon, size: 18),
                        label: Text(m.label),
                        selected: chat.mode == m,
                        onSelected: (_) => chat.setMode(m),
                      ),
                    ),
                ],
              ),
            ),
            Expanded(
              child: chat.messages.isEmpty
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.all(32),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.auto_awesome, size: 48, color: scheme.primary),
                            const SizedBox(height: 12),
                            Text(chat.mode.hint, textAlign: TextAlign.center),
                            if (settings.activeKey.isEmpty) ...[
                              const SizedBox(height: 16),
                              OutlinedButton.icon(
                                icon: const Icon(Icons.key),
                                label: const Text('Add your API key'),
                                onPressed: () => Navigator.of(context).push(
                                  MaterialPageRoute<void>(builder: (_) => const SettingsScreen()),
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                    )
                  : ListView.builder(
                      controller: _scroll,
                      padding: const EdgeInsets.all(12),
                      itemCount: chat.messages.length + (chat.loading ? 1 : 0),
                      itemBuilder: (context, i) {
                        if (i >= chat.messages.length) {
                          return const Padding(
                            padding: EdgeInsets.all(12),
                            child: Align(
                              alignment: Alignment.centerLeft,
                              child: SizedBox(
                                  width: 22,
                                  height: 22,
                                  child: CircularProgressIndicator(strokeWidth: 2)),
                            ),
                          );
                        }
                        return _Bubble(message: chat.messages[i]);
                      },
                    ),
            ),
            if (chat.error != null)
              Container(
                width: double.infinity,
                color: scheme.errorContainer,
                padding: const EdgeInsets.all(10),
                child: Text(chat.error!, style: TextStyle(color: scheme.onErrorContainer)),
              ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Expanded(
                    child: TextField(
                      controller: _input,
                      minLines: 1,
                      maxLines: 5,
                      textInputAction: TextInputAction.newline,
                      decoration: InputDecoration(
                        hintText: chat.mode.hint,
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                        contentPadding:
                            const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: chat.loading ? null : _send,
                    icon: const Icon(Icons.send),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Bubble extends StatelessWidget {
  const _Bubble({required this.message});
  final ChatMessage message;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final isUser = message.role == ChatRole.user;
    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.fromLTRB(14, 10, 8, 10),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.86),
        decoration: BoxDecoration(
          color: isUser ? scheme.primaryContainer : scheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Flexible(child: SelectableText(message.text)),
            if (!isUser)
              IconButton(
                tooltip: 'Copy',
                visualDensity: VisualDensity.compact,
                icon: const Icon(Icons.copy, size: 18),
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: message.text));
                  ScaffoldMessenger.of(context)
                      .showSnackBar(const SnackBar(content: Text('Copied')));
                },
              ),
          ],
        ),
      ),
    );
  }
}
