import 'package:flutter/material.dart';

import '../core/utils/unit_converter.dart';

class UnitConverterScreen extends StatefulWidget {
  const UnitConverterScreen({super.key});

  @override
  State<UnitConverterScreen> createState() => _UnitConverterScreenState();
}

class _UnitConverterScreenState extends State<UnitConverterScreen> {
  String _category = UnitConverter.categories.keys.first;
  late String _from = UnitConverter.categories[_category]![0].name;
  late String _to = UnitConverter.categories[_category]![1].name;
  final _value = TextEditingController(text: '1');

  @override
  void dispose() {
    _value.dispose();
    super.dispose();
  }

  void _setCategory(String c) {
    final units = UnitConverter.categories[c]!;
    setState(() {
      _category = c;
      _from = units[0].name;
      _to = units[1].name;
    });
  }

  String _result() {
    final v = double.tryParse(_value.text.replaceAll(',', '.'));
    if (v == null) return '—';
    final r = UnitConverter.convert(category: _category, from: _from, to: _to, value: v);
    final s = r.abs() >= 1e9 || (r != 0 && r.abs() < 1e-4)
        ? r.toStringAsExponential(4)
        : double.parse(r.toStringAsFixed(6)).toString();
    return s;
  }

  Widget _unitMenu(String value, ValueChanged<String> onChanged) {
    final units = UnitConverter.categories[_category]!;
    return DropdownMenu<String>(
      initialSelection: value,
      key: ValueKey('$_category-$value'),
      expandedInsets: EdgeInsets.zero,
      dropdownMenuEntries: [
        for (final u in units) DropdownMenuEntry<String>(value: u.name, label: u.name),
      ],
      onSelected: (v) {
        if (v != null) onChanged(v);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Unit Converter')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final c in UnitConverter.categories.keys)
                ChoiceChip(
                  label: Text(c),
                  selected: c == _category,
                  onSelected: (_) => _setCategory(c),
                ),
            ],
          ),
          const SizedBox(height: 20),
          TextField(
            controller: _value,
            keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
            onChanged: (_) => setState(() {}),
            decoration: const InputDecoration(labelText: 'Value', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 16),
          _unitMenu(_from, (v) => setState(() => _from = v)),
          Center(
            child: IconButton(
              icon: const Icon(Icons.swap_vert),
              onPressed: () => setState(() {
                final t = _from;
                _from = _to;
                _to = t;
              }),
            ),
          ),
          _unitMenu(_to, (v) => setState(() => _to = v)),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: scheme.primaryContainer,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              children: [
                SelectableText(_result(),
                    style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                Text(_to),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
