import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../core/utils/age_calculator.dart';

class AgeCalculatorScreen extends StatefulWidget {
  const AgeCalculatorScreen({super.key});

  @override
  State<AgeCalculatorScreen> createState() => _AgeCalculatorScreenState();
}

class _AgeCalculatorScreenState extends State<AgeCalculatorScreen> {
  bool _ageMode = true;
  DateTime? _from;
  DateTime _to = DateTime.now();
  final _fmt = DateFormat('d MMM yyyy');

  Future<DateTime?> _pick(DateTime initial) => showDatePicker(
        context: context,
        initialDate: initial,
        firstDate: DateTime(1900),
        lastDate: DateTime(2200),
      );

  @override
  Widget build(BuildContext context) {
    final from = _from;
    final to = _ageMode ? DateTime.now() : _to;
    final result = from == null ? null : AgeCalculator.between(from, to);
    final scheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(title: const Text('Age & Date')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SegmentedButton<bool>(
            segments: const [
              ButtonSegment(value: true, label: Text('Age'), icon: Icon(Icons.cake_outlined)),
              ButtonSegment(value: false, label: Text('Difference'), icon: Icon(Icons.date_range)),
            ],
            selected: {_ageMode},
            onSelectionChanged: (s) => setState(() => _ageMode = s.first),
          ),
          const SizedBox(height: 16),
          ListTile(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            tileColor: scheme.surfaceContainerHighest.withAlpha(110),
            title: Text(_ageMode ? 'Date of birth' : 'From'),
            subtitle: Text(from == null ? 'Tap to choose' : _fmt.format(from)),
            trailing: const Icon(Icons.calendar_today),
            onTap: () async {
              final d = await _pick(from ?? DateTime(2000));
              if (d != null) setState(() => _from = d);
            },
          ),
          if (!_ageMode) ...[
            const SizedBox(height: 10),
            ListTile(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              tileColor: scheme.surfaceContainerHighest.withAlpha(110),
              title: const Text('To'),
              subtitle: Text(_fmt.format(_to)),
              trailing: const Icon(Icons.calendar_today),
              onTap: () async {
                final d = await _pick(_to);
                if (d != null) setState(() => _to = d);
              },
            ),
          ],
          const SizedBox(height: 20),
          if (result != null) ...[
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: scheme.primaryContainer,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: [
                  Text('${result.years}y  ${result.months}m  ${result.days}d',
                      style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  Text('${NumberFormat.decimalPattern().format(result.totalDays)} days · '
                      '${NumberFormat.decimalPattern().format(result.totalWeeks)} weeks'),
                ],
              ),
            ),
            if (_ageMode) ...[
              const SizedBox(height: 12),
              Text(
                'Next birthday in '
                '${AgeCalculator.daysUntilNextBirthday(from!, DateTime.now())} days',
                textAlign: TextAlign.center,
              ),
            ],
          ],
        ],
      ),
    );
  }
}
