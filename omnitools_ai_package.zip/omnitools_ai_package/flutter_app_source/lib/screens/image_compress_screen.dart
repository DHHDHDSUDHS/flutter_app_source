import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../core/utils/format.dart';

class ImageCompressScreen extends StatefulWidget {
  const ImageCompressScreen({super.key});

  @override
  State<ImageCompressScreen> createState() => _ImageCompressScreenState();
}

class _ImageCompressScreenState extends State<ImageCompressScreen> {
  final _picker = ImagePicker();
  File? _original;
  Uint8List? _compressed;
  double _quality = 70;
  bool _busy = false;

  Future<void> _pick() async {
    final x = await _picker.pickImage(source: ImageSource.gallery);
    if (x == null) return;
    setState(() {
      _original = File(x.path);
      _compressed = null;
    });
    await _compress();
  }

  Future<void> _compress() async {
    final file = _original;
    if (file == null) return;
    setState(() => _busy = true);
    try {
      final bytes = await FlutterImageCompress.compressWithFile(
        file.path,
        quality: _quality.round(),
        format: CompressFormat.jpeg,
      );
      if (mounted) setState(() => _compressed = bytes);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Compression failed for this image.')));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _share() async {
    final bytes = _compressed;
    if (bytes == null) return;
    final dir = await getTemporaryDirectory();
    final out = File('${dir.path}/omnitools_${DateTime.now().millisecondsSinceEpoch}.jpg');
    await out.writeAsBytes(bytes);
    await Share.shareXFiles([XFile(out.path)], text: 'Compressed image');
  }

  @override
  Widget build(BuildContext context) {
    final original = _original;
    final compressed = _compressed;
    final before = original?.lengthSync() ?? 0;
    final after = compressed?.length ?? 0;
    final saved = before > 0 && after > 0 ? (100 - after * 100 / before) : 0.0;

    return Scaffold(
      appBar: AppBar(title: const Text('Image Compressor')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            FilledButton.icon(
              onPressed: _busy ? null : _pick,
              icon: const Icon(Icons.photo_library_outlined),
              label: const Text('Choose image'),
            ),
            if (original != null) ...[
              const SizedBox(height: 16),
              Text('Quality: ${_quality.round()}%'),
              Slider(
                value: _quality,
                min: 10,
                max: 95,
                divisions: 17,
                onChanged: (v) => setState(() => _quality = v),
                onChangeEnd: (_) => _compress(),
              ),
              if (_busy) const LinearProgressIndicator(),
              const SizedBox(height: 12),
              if (compressed != null)
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _stat('Original', formatBytes(before)),
                        _stat('Compressed', formatBytes(after)),
                        _stat('Saved', '${saved.toStringAsFixed(0)}%'),
                      ],
                    ),
                  ),
                ),
              const SizedBox(height: 12),
              if (compressed != null)
                ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: Image.memory(compressed, fit: BoxFit.contain),
                ),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: compressed == null ? null : _share,
                icon: const Icon(Icons.ios_share),
                label: const Text('Save / Share'),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _stat(String label, String value) => Column(
        children: [
          Text(label, style: const TextStyle(fontSize: 12)),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w700)),
        ],
      );
}
