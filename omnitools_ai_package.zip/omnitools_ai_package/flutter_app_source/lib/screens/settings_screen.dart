import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/constants.dart';
import '../providers/settings_provider.dart';
import '../services/ai_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final TextEditingController _openAiKey;
  late final TextEditingController _geminiKey;
  late final TextEditingController _openAiModel;
  late final TextEditingController _geminiModel;
  bool _showKeys = false;

  @override
  void initState() {
    super.initState();
    final s = context.read<SettingsProvider>();
    _openAiKey = TextEditingController(text: s.openAiKey);
    _geminiKey = TextEditingController(text: s.geminiKey);
    _openAiModel = TextEditingController(text: s.openAiModel);
    _geminiModel = TextEditingController(text: s.geminiModel);
  }

  @override
  void dispose() {
    _openAiKey.dispose();
    _geminiKey.dispose();
    _openAiModel.dispose();
    _geminiModel.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    await context.read<SettingsProvider>().saveAiConfig(
          openAiKey: _openAiKey.text,
          geminiKey: _geminiKey.text,
          openAiModel: _openAiModel.text,
          geminiModel: _geminiModel.text,
        );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Settings saved')));
  }

  Widget _field(TextEditingController c, String label, {bool secret = false}) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextField(
          controller: c,
          obscureText: secret && !_showKeys,
          autocorrect: false,
          enableSuggestions: false,
          decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final s = context.watch<SettingsProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Theme', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          SegmentedButton<ThemeMode>(
            segments: const [
              ButtonSegment(value: ThemeMode.system, label: Text('System')),
              ButtonSegment(value: ThemeMode.light, label: Text('Light')),
              ButtonSegment(value: ThemeMode.dark, label: Text('Dark')),
            ],
            selected: {s.themeMode},
            onSelectionChanged: (v) => s.setThemeMode(v.first),
          ),
          const SizedBox(height: 24),
          const Text('AI provider', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          SegmentedButton<AiProviderType>(
            segments: [
              for (final p in AiProviderType.values)
                ButtonSegment(value: p, label: Text(p.label)),
            ],
            selected: {s.provider},
            onSelectionChanged: (v) => s.setProvider(v.first),
          ),
          const SizedBox(height: 16),
          _field(_openAiKey, 'OpenAI API key', secret: true),
          _field(_openAiModel, 'OpenAI model'),
          _field(_geminiKey, 'Gemini API key', secret: true),
          _field(_geminiModel, 'Gemini model'),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Show keys'),
            value: _showKeys,
            onChanged: (v) => setState(() => _showKeys = v),
          ),
          FilledButton(onPressed: _save, child: const Text('Save')),
          const SizedBox(height: 28),
          Center(
            child: Text('${AppConstants.appName} · ${AppConstants.supportEmail}',
                style: Theme.of(context).textTheme.bodySmall),
          ),
        ],
      ),
    );
  }
}
