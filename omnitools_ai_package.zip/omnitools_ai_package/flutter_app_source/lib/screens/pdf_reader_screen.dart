import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';

class PdfReaderScreen extends StatefulWidget {
  const PdfReaderScreen({super.key});

  @override
  State<PdfReaderScreen> createState() => _PdfReaderScreenState();
}

class _PdfReaderScreenState extends State<PdfReaderScreen> {
  String? _path;
  String? _name;
  int _page = 0;
  int _total = 0;
  String? _error;

  Future<void> _pick() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['pdf'],
    );
    final file = result?.files.single;
    if (file?.path == null) return;
    setState(() {
      _path = file!.path;
      _name = file.name;
      _page = 0;
      _total = 0;
      _error = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_name ?? 'PDF Reader', overflow: TextOverflow.ellipsis),
        actions: [
          if (_total > 0)
            Center(
              child: Padding(
                padding: const EdgeInsets.only(right: 8),
                child: Text('${_page + 1} / $_total'),
              ),
            ),
          IconButton(
              tooltip: 'Open file',
              icon: const Icon(Icons.folder_open),
              onPressed: _pick),
        ],
      ),
      body: _path == null
          ? Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.picture_as_pdf, size: 64),
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    onPressed: _pick,
                    icon: const Icon(Icons.upload_file),
                    label: const Text('Choose a PDF'),
                  ),
                ],
              ),
            )
          : _error != null
              ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(_error!)))
              : PDFView(
                  filePath: _path!,
                  enableSwipe: true,
                  swipeHorizontal: false,
                  autoSpacing: true,
                  pageFling: true,
                  onRender: (pages) => setState(() => _total = pages ?? 0),
                  onPageChanged: (page, total) => setState(() {
                    _page = page ?? 0;
                    _total = total ?? _total;
                  }),
                  onError: (e) => setState(() => _error = 'Could not open this PDF.'),
                  onPageError: (page, e) => setState(() => _error = 'Could not render page $page.'),
                ),
    );
  }
}
