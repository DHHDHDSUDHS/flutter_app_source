import 'package:flutter/material.dart';

import '../core/constants.dart';
import '../services/ad_service.dart';
import '../widgets/banner_ad_widget.dart';
import '../widgets/tool_card.dart';
import 'age_calculator_screen.dart';
import 'ai_hub_screen.dart';
import 'image_compress_screen.dart';
import 'password_screen.dart';
import 'pdf_reader_screen.dart';
import 'qr_screen.dart';
import 'settings_screen.dart';
import 'unit_converter_screen.dart';

class _Tool {
  const _Tool(this.title, this.subtitle, this.icon, this.color, this.builder);
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final WidgetBuilder builder;
}

/// Home grid. To add a tool: create a screen and add one line to [_tools].
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  static final List<_Tool> _tools = [
    _Tool('AI Hub', 'Chat, summarize, write', Icons.auto_awesome, const Color(0xFF6C5CE7),
        (_) => const AiHubScreen()),
    _Tool('PDF Reader', 'Open and read PDFs', Icons.picture_as_pdf, const Color(0xFFE17055),
        (_) => const PdfReaderScreen()),
    _Tool('Image Compressor', 'Shrink photo size', Icons.compress, const Color(0xFF00B894),
        (_) => const ImageCompressScreen()),
    _Tool('QR & Barcode', 'Scan and create codes', Icons.qr_code_scanner, const Color(0xFF0984E3),
        (_) => const QrScreen()),
    _Tool('Password Generator', 'Strong random passwords', Icons.password, const Color(0xFFFDCB6E),
        (_) => const PasswordScreen()),
    _Tool('Unit Converter', 'Length, mass, data…', Icons.swap_horiz, const Color(0xFFE84393),
        (_) => const UnitConverterScreen()),
    _Tool('Age & Date', 'Age and date difference', Icons.cake_outlined, const Color(0xFF00CEC9),
        (_) => const AgeCalculatorScreen()),
    _Tool('Settings', 'Theme, AI keys', Icons.settings_outlined, const Color(0xFF636E72),
        (_) => const SettingsScreen()),
  ];

  void _open(BuildContext context, _Tool tool) {
    AdService.instance.maybeShowInterstitial();
    Navigator.of(context).push(MaterialPageRoute<void>(builder: tool.builder));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text(AppConstants.appName)),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.all(16),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 1.05,
                ),
                itemCount: _tools.length,
                itemBuilder: (context, i) {
                  final t = _tools[i];
                  return ToolCard(
                    title: t.title,
                    subtitle: t.subtitle,
                    icon: t.icon,
                    color: t.color,
                    onTap: () => _open(context, t),
                  );
                },
              ),
            ),
            const BannerAdWidget(),
          ],
        ),
      ),
    );
  }
}
