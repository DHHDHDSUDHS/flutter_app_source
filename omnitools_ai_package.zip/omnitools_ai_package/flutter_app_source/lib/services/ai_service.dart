import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import '../core/constants.dart';
import '../models/chat_message.dart';

enum AiProviderType {
  openai('OpenAI'),
  gemini('Gemini');

  const AiProviderType(this.label);
  final String label;
}

/// User-presentable error raised by [AiService].
class AiException implements Exception {
  AiException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// Talks to OpenAI or Gemini. This is the ONLY class that performs AI HTTP calls.
/// To use your own backend/proxy, change the URLs in [AppConstants] or edit
/// [_openAi] / [_gemini] below.
class AiService {
  AiService({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;
  static const Duration _timeout = Duration(seconds: 60);

  Future<String> complete({
    required AiProviderType provider,
    required String apiKey,
    required String model,
    required String systemPrompt,
    required List<ChatMessage> history,
  }) async {
    if (apiKey.trim().isEmpty) {
      throw AiException('API key missing. Open Settings and add your ${provider.label} key.');
    }
    try {
      switch (provider) {
        case AiProviderType.openai:
          return await _openAi(apiKey.trim(), model, systemPrompt, history);
        case AiProviderType.gemini:
          return await _gemini(apiKey.trim(), model, systemPrompt, history);
      }
    } on AiException {
      rethrow;
    } on SocketException {
      throw AiException('No internet connection.');
    } on TimeoutException {
      throw AiException('The request timed out. Please try again.');
    } on FormatException {
      throw AiException('Unexpected response from the server.');
    }
  }

  Future<String> _openAi(String key, String model, String system, List<ChatMessage> history) async {
    final res = await _client
        .post(
          Uri.parse(AppConstants.openAiUrl),
          headers: {
            'Authorization': 'Bearer $key',
            'Content-Type': 'application/json',
          },
          body: jsonEncode({
            'model': model,
            'messages': [
              {'role': 'system', 'content': system},
              for (final m in history)
                {
                  'role': m.role == ChatRole.user ? 'user' : 'assistant',
                  'content': m.text,
                },
            ],
          }),
        )
        .timeout(_timeout);
    final data = _decode(res);
    final text = data['choices']?[0]?['message']?['content'];
    if (text is! String || text.trim().isEmpty) {
      throw AiException('The model returned an empty response.');
    }
    return text.trim();
  }

  Future<String> _gemini(String key, String model, String system, List<ChatMessage> history) async {
    final res = await _client
        .post(
          Uri.parse('${AppConstants.geminiBaseUrl}/$model:generateContent'),
          headers: {
            'x-goog-api-key': key,
            'Content-Type': 'application/json',
          },
          body: jsonEncode({
            'systemInstruction': {
              'parts': [
                {'text': system}
              ]
            },
            'contents': [
              for (final m in history)
                {
                  'role': m.role == ChatRole.user ? 'user' : 'model',
                  'parts': [
                    {'text': m.text}
                  ],
                },
            ],
          }),
        )
        .timeout(_timeout);
    final data = _decode(res);
    final text = data['candidates']?[0]?['content']?['parts']?[0]?['text'];
    if (text is! String || text.trim().isEmpty) {
      throw AiException('The model returned an empty response.');
    }
    return text.trim();
  }

  Map<String, dynamic> _decode(http.Response res) {
    final body = utf8.decode(res.bodyBytes);
    Map<String, dynamic> data;
    try {
      data = jsonDecode(body) as Map<String, dynamic>;
    } catch (_) {
      throw AiException('Server error (${res.statusCode}).');
    }
    if (res.statusCode < 200 || res.statusCode >= 300) {
      final err = data['error'];
      final msg = err is Map ? err['message'] : null;
      throw AiException(msg is String ? msg : 'Request failed (${res.statusCode}).');
    }
    return data;
  }
}
