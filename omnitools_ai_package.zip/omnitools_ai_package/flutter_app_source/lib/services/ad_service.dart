import 'package:flutter/foundation.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

import '../core/constants.dart';

/// Central AdMob manager: interstitial + rewarded loading and frequency capping.
/// Banner ads live in `widgets/banner_ad_widget.dart`.
class AdService {
  AdService._();
  static final AdService instance = AdService._();

  bool _initialized = false;
  bool get ready => _initialized && AppConstants.adsEnabled;

  InterstitialAd? _interstitial;
  RewardedAd? _rewarded;
  int _actions = 0;

  Future<void> init() async {
    if (!AppConstants.adsEnabled) return;
    try {
      await MobileAds.instance.initialize();
      _initialized = true;
      _loadInterstitial();
      _loadRewarded();
    } catch (e) {
      debugPrint('AdMob init failed: $e');
    }
  }

  void _loadInterstitial() {
    InterstitialAd.load(
      adUnitId: AppConstants.interstitialAdUnitId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) => _interstitial = ad,
        onAdFailedToLoad: (_) => _interstitial = null,
      ),
    );
  }

  void _loadRewarded() {
    RewardedAd.load(
      adUnitId: AppConstants.rewardedAdUnitId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) => _rewarded = ad,
        onAdFailedToLoad: (_) => _rewarded = null,
      ),
    );
  }

  /// Call whenever the user opens a tool; shows an interstitial every N calls.
  void maybeShowInterstitial() {
    if (!ready) return;
    _actions++;
    if (_actions % AppConstants.interstitialEvery != 0) return;
    final ad = _interstitial;
    if (ad == null) {
      _loadInterstitial();
      return;
    }
    _interstitial = null;
    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (a) {
        a.dispose();
        _loadInterstitial();
      },
      onAdFailedToShowFullScreenContent: (a, _) {
        a.dispose();
        _loadInterstitial();
      },
    );
    ad.show();
  }

  /// Shows a rewarded ad. [onReward] fires when the user earns the reward;
  /// [onUnavailable] fires when no ad is ready.
  void showRewarded({required VoidCallback onReward, VoidCallback? onUnavailable}) {
    final ad = _rewarded;
    if (!ready || ad == null) {
      _loadRewarded();
      onUnavailable?.call();
      return;
    }
    _rewarded = null;
    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (a) {
        a.dispose();
        _loadRewarded();
      },
      onAdFailedToShowFullScreenContent: (a, _) {
        a.dispose();
        _loadRewarded();
      },
    );
    ad.show(onUserEarnedReward: (_, __) => onReward());
  }
}
