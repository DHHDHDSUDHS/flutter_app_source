import 'dart:io' show Platform;
import 'package:flutter/material.dart';

/// ===========================================================
///  RE-SKIN CENTER  -  edit this file to rebrand the whole app.
///  Name, colors, ad IDs, AI defaults and credit rules live here.
/// ===========================================================
class AppConstants {
  AppConstants._();

  // ---- Branding -------------------------------------------------
  static const String appName = 'OmniTools AI';
  static const String appTagline = 'Everything you need, in one app';
  static const String supportEmail = 'support@yourdomain.com';
  static const Color primaryColor = Color(0xFF6C5CE7);
  static const Color accentColor = Color(0xFF00CEC9);

  // ---- AI defaults (users can override in Settings) ---------------
  static const String defaultOpenAiModel = 'gpt-4o-mini';
  static const String defaultGeminiModel = 'gemini-1.5-flash';
  static const String openAiUrl = 'https://api.openai.com/v1/chat/completions';
  static const String geminiBaseUrl =
      'https://generativelanguage.googleapis.com/v1beta/models';

  // ---- Monetization ---------------------------------------------
  /// Master switch. false = no ads and unlimited AI messages.
  static const bool adsEnabled = true;

  /// Free AI messages per day before a rewarded ad is required.
  static const int dailyFreeAiCredits = 10;

  /// Credits granted after watching one rewarded ad.
  static const int creditsPerRewardedAd = 5;

  /// Show an interstitial every N tool openings.
  static const int interstitialEvery = 3;

  /// true = Google's official test ads (safe while developing).
  /// Set to false and fill the IDs below before publishing.
  static const bool useTestAds = true;

  // Your real AdMob unit IDs (used when useTestAds == false)
  static const String androidBannerId = 'REPLACE_WITH_ANDROID_BANNER_ID';
  static const String androidInterstitialId = 'REPLACE_WITH_ANDROID_INTERSTITIAL_ID';
  static const String androidRewardedId = 'REPLACE_WITH_ANDROID_REWARDED_ID';
  static const String iosBannerId = 'REPLACE_WITH_IOS_BANNER_ID';
  static const String iosInterstitialId = 'REPLACE_WITH_IOS_INTERSTITIAL_ID';
  static const String iosRewardedId = 'REPLACE_WITH_IOS_REWARDED_ID';

  // Google's public test unit IDs
  static const String _testBannerAndroid = 'ca-app-pub-3940256099942544/6300978111';
  static const String _testInterAndroid = 'ca-app-pub-3940256099942544/1033173712';
  static const String _testRewardAndroid = 'ca-app-pub-3940256099942544/5224354917';
  static const String _testBannerIos = 'ca-app-pub-3940256099942544/2934735716';
  static const String _testInterIos = 'ca-app-pub-3940256099942544/4411468910';
  static const String _testRewardIos = 'ca-app-pub-3940256099942544/1712485313';

  static String get bannerAdUnitId => useTestAds
      ? (Platform.isAndroid ? _testBannerAndroid : _testBannerIos)
      : (Platform.isAndroid ? androidBannerId : iosBannerId);

  static String get interstitialAdUnitId => useTestAds
      ? (Platform.isAndroid ? _testInterAndroid : _testInterIos)
      : (Platform.isAndroid ? androidInterstitialId : iosInterstitialId);

  static String get rewardedAdUnitId => useTestAds
      ? (Platform.isAndroid ? _testRewardAndroid : _testRewardIos)
      : (Platform.isAndroid ? androidRewardedId : iosRewardedId);
}
