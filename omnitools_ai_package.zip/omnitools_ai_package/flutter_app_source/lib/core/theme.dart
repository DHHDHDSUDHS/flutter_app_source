import 'package:flutter/material.dart';
import 'constants.dart';

/// Material 3 light/dark themes generated from [AppConstants.primaryColor].
class AppTheme {
  AppTheme._();

  static ThemeData light() => _build(Brightness.light);
  static ThemeData dark() => _build(Brightness.dark);

  static ThemeData _build(Brightness brightness) {
    final scheme = ColorScheme.fromSeed(
      seedColor: AppConstants.primaryColor,
      secondary: AppConstants.accentColor,
      brightness: brightness,
    );
    final dark = brightness == Brightness.dark;
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor:
          dark ? const Color(0xFF0E0E14) : const Color(0xFFF6F6FB),
    );
  }
}
