/// Result of an age / date-difference calculation.
class AgeResult {
  const AgeResult({
    required this.years,
    required this.months,
    required this.days,
    required this.totalDays,
  });

  final int years;
  final int months;
  final int days;
  final int totalDays;

  int get totalWeeks => totalDays ~/ 7;
}

/// Calendar-accurate age maths (pure Dart, unit-tested).
class AgeCalculator {
  AgeCalculator._();

  static DateTime _d(DateTime x) => DateTime(x.year, x.month, x.day);

  /// Difference between [from] and [to]; the arguments are swapped if needed.
  static AgeResult between(DateTime from, DateTime to) {
    var a = _d(from);
    var b = _d(to);
    if (a.isAfter(b)) {
      final tmp = a;
      a = b;
      b = tmp;
    }
    var years = b.year - a.year;
    var months = b.month - a.month;
    var days = b.day - a.day;
    if (days < 0) {
      days += DateTime(b.year, b.month, 0).day; // length of previous month
      months -= 1;
    }
    if (months < 0) {
      months += 12;
      years -= 1;
    }
    return AgeResult(
        years: years, months: months, days: days, totalDays: b.difference(a).inDays);
  }

  /// Days until the next birthday (0 when today is the birthday).
  static int daysUntilNextBirthday(DateTime birth, DateTime today) {
    final t = _d(today);
    var next = DateTime(t.year, birth.month, birth.day);
    if (next.isBefore(t)) next = DateTime(t.year + 1, birth.month, birth.day);
    return next.difference(t).inDays;
  }
}
