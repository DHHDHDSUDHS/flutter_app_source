/// A unit with its multiplier to the category's base unit.
class UnitDef {
  const UnitDef(this.name, this.factor);
  final String name;
  final double factor;
}

/// Pure-Dart unit conversion engine (unit-tested).
class UnitConverter {
  UnitConverter._();

  static const String temperature = 'Temperature';

  static const Map<String, List<UnitDef>> categories = {
    'Length': [
      UnitDef('Meter', 1),
      UnitDef('Kilometer', 1000),
      UnitDef('Centimeter', 0.01),
      UnitDef('Millimeter', 0.001),
      UnitDef('Mile', 1609.344),
      UnitDef('Yard', 0.9144),
      UnitDef('Foot', 0.3048),
      UnitDef('Inch', 0.0254),
    ],
    'Mass': [
      UnitDef('Kilogram', 1),
      UnitDef('Gram', 0.001),
      UnitDef('Milligram', 0.000001),
      UnitDef('Tonne', 1000),
      UnitDef('Pound', 0.45359237),
      UnitDef('Ounce', 0.028349523125),
    ],
    'Volume': [
      UnitDef('Liter', 1),
      UnitDef('Milliliter', 0.001),
      UnitDef('Cubic meter', 1000),
      UnitDef('US gallon', 3.785411784),
      UnitDef('US cup', 0.2365882365),
    ],
    'Speed': [
      UnitDef('m/s', 1),
      UnitDef('km/h', 0.2777777777777778),
      UnitDef('mph', 0.44704),
      UnitDef('Knot', 0.5144444444444445),
    ],
    'Data': [
      UnitDef('Byte', 1),
      UnitDef('KB', 1024),
      UnitDef('MB', 1048576),
      UnitDef('GB', 1073741824),
      UnitDef('TB', 1099511627776),
    ],
    temperature: [
      UnitDef('Celsius', 1),
      UnitDef('Fahrenheit', 1),
      UnitDef('Kelvin', 1),
    ],
  };

  static double convert({
    required String category,
    required String from,
    required String to,
    required double value,
  }) {
    if (category == temperature) return _temperature(from, to, value);
    final units = categories[category];
    if (units == null) throw ArgumentError('Unknown category: $category');
    double factorOf(String name) => units
        .firstWhere((u) => u.name == name,
            orElse: () => throw ArgumentError('Unknown unit: $name'))
        .factor;
    return value * factorOf(from) / factorOf(to);
  }

  static double _temperature(String from, String to, double value) {
    double c;
    switch (from) {
      case 'Celsius':
        c = value;
        break;
      case 'Fahrenheit':
        c = (value - 32) * 5 / 9;
        break;
      case 'Kelvin':
        c = value - 273.15;
        break;
      default:
        throw ArgumentError('Unknown unit: $from');
    }
    switch (to) {
      case 'Celsius':
        return c;
      case 'Fahrenheit':
        return c * 9 / 5 + 32;
      case 'Kelvin':
        return c + 273.15;
      default:
        throw ArgumentError('Unknown unit: $to');
    }
  }
}
