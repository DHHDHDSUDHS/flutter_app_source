import 'dart:math';

/// Options for [PasswordGenerator].
class PasswordOptions {
  const PasswordOptions({
    this.length = 16,
    this.upper = true,
    this.lower = true,
    this.digits = true,
    this.symbols = true,
  });

  final int length;
  final bool upper;
  final bool lower;
  final bool digits;
  final bool symbols;

  bool get hasAny => upper || lower || digits || symbols;

  PasswordOptions copyWith({int? length, bool? upper, bool? lower, bool? digits, bool? symbols}) =>
      PasswordOptions(
        length: length ?? this.length,
        upper: upper ?? this.upper,
        lower: lower ?? this.lower,
        digits: digits ?? this.digits,
        symbols: symbols ?? this.symbols,
      );
}

/// Cryptographically secure password generator (pure Dart, unit-tested).
class PasswordGenerator {
  PasswordGenerator._();

  static const String _upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  static const String _lower = 'abcdefghijklmnopqrstuvwxyz';
  static const String _digits = '0123456789';
  static const String _symbols = '!@#\$%^&*()-_=+[]{};:,.?';

  static List<String> _pools(PasswordOptions o) => <String>[
        if (o.upper) _upper,
        if (o.lower) _lower,
        if (o.digits) _digits,
        if (o.symbols) _symbols,
      ];

  /// Generates a password containing at least one char of every enabled set.
  static String generate(PasswordOptions o, {Random? random}) {
    final rnd = random ?? Random.secure();
    final pools = _pools(o);
    if (pools.isEmpty) throw ArgumentError('Select at least one character set.');
    if (o.length < pools.length) {
      throw ArgumentError('Length is too short for the selected sets.');
    }
    final chars = <String>[for (final p in pools) p[rnd.nextInt(p.length)]];
    final all = pools.join();
    while (chars.length < o.length) {
      chars.add(all[rnd.nextInt(all.length)]);
    }
    chars.shuffle(rnd);
    return chars.join();
  }

  /// Theoretical entropy in bits for the given options.
  static double entropyBits(PasswordOptions o) {
    final poolSize = _pools(o).join().length;
    if (poolSize == 0) return 0;
    return o.length * (log(poolSize) / ln2);
  }

  static String strengthLabel(double bits) {
    if (bits < 40) return 'Weak';
    if (bits < 60) return 'Fair';
    if (bits < 80) return 'Strong';
    return 'Excellent';
  }
}
