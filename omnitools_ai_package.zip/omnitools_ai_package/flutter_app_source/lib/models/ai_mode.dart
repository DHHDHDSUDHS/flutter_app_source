import 'package:flutter/material.dart';

/// AI Hub modes. Each mode = a label + a system prompt.
/// Add a new mode here and it appears automatically in the UI.
enum AiMode {
  chat('Chat', Icons.chat_bubble_outline,
      'You are a helpful, concise assistant.', 'Ask me anything…'),
  summarize('Summarize', Icons.short_text,
      'Summarize the user text into clear bullet points. Keep key facts and numbers.',
      'Paste an article or text to summarize…'),
  write('Write', Icons.edit_note,
      'You are a professional writer. Produce polished text in the requested style.',
      'What should I write? (email, post, bio…)'),
  ideas('Ideas', Icons.lightbulb_outline,
      'Brainstorm 8 creative, specific ideas as a numbered list.',
      'What do you need ideas for?');

  const AiMode(this.label, this.icon, this.systemPrompt, this.hint);

  final String label;
  final IconData icon;
  final String systemPrompt;
  final String hint;
}
