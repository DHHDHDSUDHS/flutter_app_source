import 'package:flutter/foundation.dart';

import '../models/ai_mode.dart';
import '../models/chat_message.dart';
import '../services/ai_service.dart';
import 'settings_provider.dart';

/// State for the AI Hub screen (messages, mode, loading and error state).
class AiChatProvider extends ChangeNotifier {
  AiChatProvider({AiService? service}) : _service = service ?? AiService();

  final AiService _service;
  final List<ChatMessage> messages = [];
  AiMode mode = AiMode.chat;
  bool loading = false;
  String? error;

  void setMode(AiMode m) {
    mode = m;
    notifyListeners();
  }

  void clear() {
    messages.clear();
    error = null;
    notifyListeners();
  }

  Future<void> send(String text, SettingsProvider settings) async {
    final trimmed = text.trim();
    if (trimmed.isEmpty || loading) return;
    error = null;
    messages.add(ChatMessage(role: ChatRole.user, text: trimmed));
    loading = true;
    notifyListeners();
    try {
      final reply = await _service.complete(
        provider: settings.provider,
        apiKey: settings.activeKey,
        model: settings.activeModel,
        systemPrompt: mode.systemPrompt,
        // Only Chat mode keeps conversation context.
        history: mode == AiMode.chat ? List.of(messages) : [messages.last],
      );
      messages.add(ChatMessage(role: ChatRole.assistant, text: reply));
      await settings.consumeCredit();
    } on AiException catch (e) {
      error = e.message;
    } catch (e) {
      error = 'Unexpected error: $e';
    } finally {
      loading = false;
      notifyListeners();
    }
  }
}
