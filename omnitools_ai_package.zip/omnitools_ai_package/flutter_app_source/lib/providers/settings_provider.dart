import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/constants.dart';
import '../services/ai_service.dart';

/// App-wide settings: theme, AI provider/keys/models and daily AI credits.
/// API keys are kept in the platform keystore (flutter_secure_storage).
class SettingsProvider extends ChangeNotifier {
  static const _kTheme = 'theme_mode';
  static const _kProvider = 'ai_provider';
  static const _kOpenAiModel = 'openai_model';
  static const _kGeminiModel = 'gemini_model';
  static const _kCredits = 'ai_credits';
  static const _kCreditDate = 'ai_credit_date';
  static const _kOpenAiKey = 'openai_key';
  static const _kGeminiKey = 'gemini_key';

  final FlutterSecureStorage _secure = const FlutterSecureStorage();
  late SharedPreferences _prefs;

  ThemeMode themeMode = ThemeMode.system;
  AiProviderType provider = AiProviderType.openai;
  String openAiKey = '';
  String geminiKey = '';
  String openAiModel = AppConstants.defaultOpenAiModel;
  String geminiModel = AppConstants.defaultGeminiModel;
  int aiCredits = AppConstants.dailyFreeAiCredits;

  String get activeKey => provider == AiProviderType.openai ? openAiKey : geminiKey;
  String get activeModel => provider == AiProviderType.openai ? openAiModel : geminiModel;
  bool get hasCredits => !AppConstants.adsEnabled || aiCredits > 0;

  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();
    themeMode = ThemeMode.values[(_prefs.getInt(_kTheme) ?? 0).clamp(0, 2).toInt()];
    provider = AiProviderType.values[(_prefs.getInt(_kProvider) ?? 0).clamp(0, 1).toInt()];
    openAiModel = _prefs.getString(_kOpenAiModel) ?? openAiModel;
    geminiModel = _prefs.getString(_kGeminiModel) ?? geminiModel;
    try {
      openAiKey = await _secure.read(key: _kOpenAiKey) ?? '';
      geminiKey = await _secure.read(key: _kGeminiKey) ?? '';
    } catch (_) {
      // Keystore unavailable (e.g. in unit tests): keys stay empty.
    }
    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
    if (_prefs.getString(_kCreditDate) != today) {
      aiCredits = AppConstants.dailyFreeAiCredits;
      await _prefs.setString(_kCreditDate, today);
      await _prefs.setInt(_kCredits, aiCredits);
    } else {
      aiCredits = _prefs.getInt(_kCredits) ?? AppConstants.dailyFreeAiCredits;
    }
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    themeMode = mode;
    notifyListeners();
    await _prefs.setInt(_kTheme, mode.index);
  }

  Future<void> setProvider(AiProviderType p) async {
    provider = p;
    notifyListeners();
    await _prefs.setInt(_kProvider, p.index);
  }

  Future<void> saveAiConfig({
    required String openAiKey,
    required String geminiKey,
    required String openAiModel,
    required String geminiModel,
  }) async {
    this.openAiKey = openAiKey.trim();
    this.geminiKey = geminiKey.trim();
    this.openAiModel = openAiModel.trim().isEmpty ? AppConstants.defaultOpenAiModel : openAiModel.trim();
    this.geminiModel = geminiModel.trim().isEmpty ? AppConstants.defaultGeminiModel : geminiModel.trim();
    notifyListeners();
    await _prefs.setString(_kOpenAiModel, this.openAiModel);
    await _prefs.setString(_kGeminiModel, this.geminiModel);
    try {
      await _secure.write(key: _kOpenAiKey, value: this.openAiKey);
      await _secure.write(key: _kGeminiKey, value: this.geminiKey);
    } catch (_) {}
  }

  Future<void> consumeCredit() async {
    if (!AppConstants.adsEnabled || aiCredits <= 0) return;
    aiCredits--;
    notifyListeners();
    await _prefs.setInt(_kCredits, aiCredits);
  }

  Future<void> grantCredits(int n) async {
    aiCredits += n;
    notifyListeners();
    await _prefs.setInt(_kCredits, aiCredits);
  }
}
