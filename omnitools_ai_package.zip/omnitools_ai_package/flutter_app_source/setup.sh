#!/usr/bin/env bash
# One-shot project setup. Usage: ./setup.sh com.yourcompany
set -euo pipefail
ORG="${1:-com.example}"
flutter create --org "$ORG" --project-name omnitools_ai --platforms android,ios .
python3 tools/patch_platform_config.py
flutter pub get
flutter analyze
flutter test
echo "Done. Run:  flutter run"
