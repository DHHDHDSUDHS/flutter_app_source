import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:omnitools_ai/models/chat_message.dart';
import 'package:omnitools_ai/services/ai_service.dart';

const _history = [ChatMessage(role: ChatRole.user, text: 'Hello')];

Future<String> _run(AiService s, AiProviderType p, {String key = 'k'}) => s.complete(
      provider: p,
      apiKey: key,
      model: 'm',
      systemPrompt: 'sys',
      history: _history,
    );

http.Response _json(Object body, [int code = 200]) =>
    http.Response(jsonEncode(body), code, headers: {'content-type': 'application/json'});

void main() {
  group('AiService', () {
    test('OpenAI success sends bearer token and parses reply', () async {
      final client = MockClient((req) async {
        expect(req.headers['Authorization'], 'Bearer k');
        final body = jsonDecode(req.body) as Map<String, dynamic>;
        expect((body['messages'] as List).first['role'], 'system');
        return _json({
          'choices': [
            {'message': {'content': ' Hi there '}}
          ]
        });
      });
      expect(await _run(AiService(client: client), AiProviderType.openai), 'Hi there');
    });

    test('Gemini success sends api key header and parses reply', () async {
      final client = MockClient((req) async {
        expect(req.headers['x-goog-api-key'], 'k');
        expect(req.url.path.endsWith('m:generateContent'), isTrue);
        return _json({
          'candidates': [
            {
              'content': {
                'parts': [
                  {'text': 'Hola'}
                ]
              }
            }
          ]
        });
      });
      expect(await _run(AiService(client: client), AiProviderType.gemini), 'Hola');
    });

    test('missing key throws friendly error', () async {
      final s = AiService(client: MockClient((_) async => _json({})));
      expect(_run(s, AiProviderType.openai, key: '  '), throwsA(isA<AiException>()));
    });

    test('API error message is surfaced', () async {
      final client = MockClient((_) async => _json({
            'error': {'message': 'Invalid key'}
          }, 401));
      expect(
        _run(AiService(client: client), AiProviderType.openai),
        throwsA(isA<AiException>().having((e) => e.message, 'message', 'Invalid key')),
      );
    });

    test('empty model output throws', () async {
      final client = MockClient((_) async => _json({'choices': []}));
      expect(_run(AiService(client: client), AiProviderType.openai), throwsA(isA<AiException>()));
    });
  });
}
