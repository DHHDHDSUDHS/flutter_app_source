import 'package:flutter_test/flutter_test.dart';
import 'package:omnitools_ai/core/utils/unit_converter.dart';

double c(String cat, String from, String to, double v) =>
    UnitConverter.convert(category: cat, from: from, to: to, value: v);

void main() {
  group('UnitConverter', () {
    test('length', () {
      expect(c('Length', 'Kilometer', 'Meter', 1), closeTo(1000, 1e-9));
      expect(c('Length', 'Mile', 'Kilometer', 1), closeTo(1.609344, 1e-9));
      expect(c('Length', 'Inch', 'Centimeter', 1), closeTo(2.54, 1e-9));
    });

    test('mass', () {
      expect(c('Mass', 'Pound', 'Kilogram', 1), closeTo(0.45359237, 1e-9));
      expect(c('Mass', 'Kilogram', 'Gram', 2.5), closeTo(2500, 1e-9));
    });

    test('data uses binary multiples', () {
      expect(c('Data', 'MB', 'KB', 1), closeTo(1024, 1e-9));
      expect(c('Data', 'GB', 'MB', 2), closeTo(2048, 1e-9));
    });

    test('speed', () {
      expect(c('Speed', 'km/h', 'm/s', 36), closeTo(10, 1e-9));
    });

    test('temperature', () {
      expect(c('Temperature', 'Celsius', 'Fahrenheit', 100), closeTo(212, 1e-9));
      expect(c('Temperature', 'Fahrenheit', 'Celsius', 32), closeTo(0, 1e-9));
      expect(c('Temperature', 'Celsius', 'Kelvin', 0), closeTo(273.15, 1e-9));
    });

    test('round trip is stable', () {
      final there = c('Volume', 'US gallon', 'Liter', 3);
      expect(c('Volume', 'Liter', 'US gallon', there), closeTo(3, 1e-9));
    });

    test('unknown unit or category throws', () {
      expect(() => c('Length', 'Parsec', 'Meter', 1), throwsArgumentError);
      expect(() => c('Nope', 'A', 'B', 1), throwsArgumentError);
    });
  });
}
