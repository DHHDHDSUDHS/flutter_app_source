import 'package:flutter_test/flutter_test.dart';
import 'package:omnitools_ai/main.dart';
import 'package:omnitools_ai/providers/settings_provider.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  testWidgets('home screen renders the tool grid', (tester) async {
    SharedPreferences.setMockInitialValues({});
    final settings = SettingsProvider();
    await settings.load();
    await tester.pumpWidget(
      ChangeNotifierProvider.value(value: settings, child: const OmniToolsApp()),
    );
    await tester.pumpAndSettle();
    expect(find.text('OmniTools AI'), findsWidgets);
    expect(find.text('AI Hub'), findsOneWidget);
  });
}
