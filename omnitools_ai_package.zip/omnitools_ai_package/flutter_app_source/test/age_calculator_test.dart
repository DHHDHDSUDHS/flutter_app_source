import 'package:flutter_test/flutter_test.dart';
import 'package:omnitools_ai/core/utils/age_calculator.dart';
import 'package:omnitools_ai/core/utils/format.dart';

void main() {
  group('AgeCalculator', () {
    test('years, months, days across a leap February', () {
      final r = AgeCalculator.between(DateTime(2000, 1, 15), DateTime(2024, 3, 10));
      expect([r.years, r.months, r.days], [24, 1, 24]);
    });

    test('exact birthday gives zero months and days', () {
      final r = AgeCalculator.between(DateTime(1990, 6, 1), DateTime(2020, 6, 1));
      expect([r.years, r.months, r.days], [30, 0, 0]);
    });

    test('total days', () {
      final r = AgeCalculator.between(DateTime(2024, 1, 1), DateTime(2024, 12, 31));
      expect(r.totalDays, 365);
      expect(r.totalWeeks, 52);
    });

    test('swaps reversed arguments', () {
      final r = AgeCalculator.between(DateTime(2024, 3, 10), DateTime(2000, 1, 15));
      expect([r.years, r.months, r.days], [24, 1, 24]);
    });

    test('next birthday', () {
      expect(AgeCalculator.daysUntilNextBirthday(DateTime(1990, 6, 10), DateTime(2024, 6, 1)), 9);
      expect(AgeCalculator.daysUntilNextBirthday(DateTime(1990, 6, 1), DateTime(2024, 6, 1)), 0);
      expect(AgeCalculator.daysUntilNextBirthday(DateTime(1990, 1, 1), DateTime(2024, 12, 31)), 1);
    });
  });

  group('formatBytes', () {
    test('formats units', () {
      expect(formatBytes(512), '512 B');
      expect(formatBytes(1536), '1.5 KB');
      expect(formatBytes(5 * 1024 * 1024), '5.00 MB');
    });
  });
}
