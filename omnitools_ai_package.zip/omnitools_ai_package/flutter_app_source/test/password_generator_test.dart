import 'dart:math';

import 'package:flutter_test/flutter_test.dart';
import 'package:omnitools_ai/core/utils/password_generator.dart';

void main() {
  group('PasswordGenerator', () {
    test('respects requested length', () {
      for (final len in [8, 16, 32, 64]) {
        final p = PasswordGenerator.generate(PasswordOptions(length: len));
        expect(p.length, len);
      }
    });

    test('contains every enabled character set', () {
      for (var i = 0; i < 200; i++) {
        final p = PasswordGenerator.generate(const PasswordOptions(length: 8));
        expect(RegExp(r'[A-Z]').hasMatch(p), isTrue);
        expect(RegExp(r'[a-z]').hasMatch(p), isTrue);
        expect(RegExp(r'[0-9]').hasMatch(p), isTrue);
        expect(RegExp(r'[^A-Za-z0-9]').hasMatch(p), isTrue);
      }
    });

    test('digits only', () {
      final p = PasswordGenerator.generate(
          const PasswordOptions(length: 20, upper: false, lower: false, symbols: false));
      expect(RegExp(r'^[0-9]{20}$').hasMatch(p), isTrue);
    });

    test('is deterministic with a seeded Random', () {
      final a = PasswordGenerator.generate(const PasswordOptions(), random: Random(7));
      final b = PasswordGenerator.generate(const PasswordOptions(), random: Random(7));
      expect(a, b);
    });

    test('throws when no set is selected', () {
      expect(
        () => PasswordGenerator.generate(
            const PasswordOptions(upper: false, lower: false, digits: false, symbols: false)),
        throwsArgumentError,
      );
    });

    test('entropy grows with length and strength labels map', () {
      final short = PasswordGenerator.entropyBits(const PasswordOptions(length: 8));
      final long = PasswordGenerator.entropyBits(const PasswordOptions(length: 24));
      expect(long, greaterThan(short));
      expect(PasswordGenerator.strengthLabel(30), 'Weak');
      expect(PasswordGenerator.strengthLabel(100), 'Excellent');
    });
  });
}
